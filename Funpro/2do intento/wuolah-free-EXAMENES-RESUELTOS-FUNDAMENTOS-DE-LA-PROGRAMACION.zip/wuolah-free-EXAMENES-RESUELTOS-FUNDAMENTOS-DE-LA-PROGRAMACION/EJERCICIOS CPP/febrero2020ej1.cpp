#include <iostream>
#include <cmath>
using namespace std;

bool esPrimo(int& num)
{
	bool res = true;
	int divisor,tope;
	if (num==1)
	{
		res=false;
	}
	if (num>=2)
	{
		tope=sqrt(num);
		for (int d=2;d<num-1;d++)
		{
			if (num%d==0)
			{
				res=false;
		 }
		}
	}
	return res;
}

int main() {
	int num,
		mayor=0;
	cout<<"Introduzca una secuencia de enteros positivos acabada en 0: ";
	cin>>num;
	while (num!=0)
	{
		if (num>mayor && esPrimo(num))
		{
			mayor=num;
		}
		cin>>num;
	}
	if (mayor==0)
	{
		cout<<"No hay ningun primo en la secuencia";
	}
	else
	{
		cout<<"El mayor primo es "<<mayor;
	}
	return 0;
}

